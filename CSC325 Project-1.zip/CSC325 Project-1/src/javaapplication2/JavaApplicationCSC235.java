/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication2;

import java.util.Scanner;

/**
 *
 * @author abudi
 */
public class JavaApplicationCSC235 {

    /**
     * @param args the command line arguments
     */

    public static void main(String[] args) { 
        Scanner scanner = new Scanner(System.in); // Creates a Scanner object to read keyboard input from System.in
        System.out.println("Type expressions like: 3 + 5 * 2, (10 - 2) / 4, or type 'ans'"); // Displays example instructions to the user.
        System.out.println("Type 'exit' to quit.\n"); // Explains to the user how to exit the program.

        while (true) { // Starts an infinite loop so the program keeps asking for input until broken.
            System.out.print("calc> "); // Prints the command prompt prompt without a newline.
            String input = scanner.nextLine(); // Reads the entire line of text typed by the user.

            if (input.equalsIgnoreCase("exit")) { // Checks if the user typed "exit" (ignoring uppercase/lowercase).
                System.out.println("Goodbye!"); // Prints a farewell message before quitting.
                break; // Exits the infinite while loop to end the program.
            } // Ends the exit check block.
            if (input.isEmpty()) continue; // If the user just pressed Enter without typing anything, skip to the next loop iteration.

            try { // Opens a try block to safely attempt running code that might throw an error.
                double result = evaluate(input); // Calls the evaluate function on the input and stores the numerical result.
                double lastAnswer = result; // Stores the result in a variable named lastAnswer for potential future use.
                System.out.println("  = " + result); // Prints the calculated result back to the user.
            } catch (Exception e) { // Catches any error/exception thrown during expression evaluation.
                System.out.println("  [Error]: " + e.getMessage()); // Prints the descriptive error message to the console.
            } // Ends the try-catch block.
        } // Ends the main while loop.
        scanner.close(); // Closes the Scanner resource to release memory and avoid resource leaks.
    } // Ends the main method.

    // Main evaluation router
    public static double evaluate(String expr) { // Helper method that receives a raw math expression string and returns its evaluated double value.
        // Clean out any spaces
        expr = expr.replaceAll("\\s+", ""); // Uses regular expressions to strip out all spaces, tabs, and whitespace from the string.
        
        // Replace keyword 'ans' with the stored number value
     //   expr = expr.replace("ans", String.valueOf(lastAnswer)); // Commented-out placeholder for substituting 'ans' with a stored value.

        return parseAdditionAndSubtraction(expr); // Passes the cleaned string to the first level of parsing (lowest precedence operators).
    } // Ends the evaluate method.

    // 1. Lowest Precedence: Handles '+' and '-'
    private static double parseAdditionAndSubtraction(String expr) { // Evaluates addition and subtraction from left to right.
        int parenCount = 0; // Initializes a counter to track depth inside nested parentheses.
        // Scan backwards to find lowest precedence operator outside of parentheses
        for (int i = expr.length() - 1; i >= 0; i--) { // Loops through the string characters backwards (from rightmost to leftmost).
            char c = expr.charAt(i); // Grabs the character at the current index i.
            if (c == ')') parenCount++; // Increments parenCount when encountering a closing parenthesis (since we move backwards).
            else if (c == '(') parenCount--; // Decrements parenCount when encountering an opening parenthesis.
            else if (parenCount == 0 && (c == '+' || c == '-')) { // Checks if we found a + or - outside of any parentheses.
                double left = parseAdditionAndSubtraction(expr.substring(0, i)); // Recursively parses everything to the left of the operator.
                double right = parseMultiplicationAndDivision(expr.substring(i + 1)); // Parses everything to the right of the operator at higher precedence.
                return (c == '+') ? (left + right) : (left - right); // (condition) ? (do this if true) : (do this if false).. Returns left + right if the character is '+', otherwise left - right.
            } // Ends the operator match check.
        } // Ends the backwards for loop.
        return parseMultiplicationAndDivision(expr); // If no + or - was found outside parentheses, hand off parsing to higher precedence rules.
    } // Ends the parseAdditionAndSubtraction method.

    // 2. Higher Precedence: Handles '*' and '/'
    private static double parseMultiplicationAndDivision(String expr) { // Evaluates multiplication and division.
        int parenCount = 0; // Tracks parenthesis depth level just like in addition/subtraction.
        for (int i = expr.length() - 1; i >= 0; i--) { // Loops backwards through the string to check operators from right to left.
            char c = expr.charAt(i); // Retrieves the character at position i.
            if (c == ')') parenCount++; // Increases nesting level for closing parenthesis.
            else if (c == '(') parenCount--; // Decreases nesting level for opening parenthesis.
            else if (parenCount == 0 && (c == '*' || c == '/')) { // Checks if we found a * or / outside of parentheses.
                double left = parseMultiplicationAndDivision(expr.substring(0, i)); // Recursively evaluates the left sub-expression.
                double right = parseFactor(expr.substring(i + 1)); // Evaluates the right side at the highest precedence level (factors/numbers).
                if (c == '*') return left * right; // Multiplies left and right if operator is '*'.
                if (right == 0.0) throw new ArithmeticException("Division by zero is not allowed"); // Throws an explicit error if dividing by 0.0.
                return left / right; // Returns the division quotient if valid.
            } // Ends the operator match check.
        } // Ends the backwards for loop.
        return parseFactor(expr); // If no * or / was found outside parentheses, move to evaluating raw factors.
    } // Ends the parseMultiplicationAndDivision method.

    // 3. Highest Precedence: Numbers and Parentheses
    private static double parseFactor(String expr) { // Evaluates individual numeric values or expressions inside parentheses.
        if (expr.isEmpty()) { // Checks if the sub-expression string is completely empty.
            throw new RuntimeException("Syntax Error: Missing value or expression"); // Throws a syntax error if an operator has missing operands.
        } // Ends empty check.

        // Handle parentheses wrapper like "(3 + 2)"
        if (expr.startsWith("(") && expr.endsWith(")")) { // Checks if the whole term is wrapped inside parentheses.
            return evaluate(expr.substring(1, expr.length() - 1)); // Strips outer '(' and ')' and sends inner text back to evaluate.
        } // Ends parenthesis wrapper check.

        // Convert raw number text into a double
        try { // Attempts to parse string text directly into a numeric value.
            return Double.parseDouble(expr); // Converts numeric string text (e.g. "42.5") into a primitive double number and returns it.
        } catch (NumberFormatException e) { // Catches error if the text is not a valid floating-point number.
            throw new RuntimeException("Syntax Error: Unrecognized token or invalid number '" + expr + "'"); // Throws formatted syntax error.
        } // Ends try-catch block.
    } // Ends parseFactor method.
    }
    

